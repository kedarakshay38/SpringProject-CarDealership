package com.cdac.service;

import java.util.List;



import com.cdac.dto.CarModel;



public interface CarModelservice {
 void insertcar(CarModel car);
 void removeCar(int chassino);
 CarModel findCar(int chassino);
 void modifyCar(CarModel car);
	List<CarModel> selectAll(int userId);
}
