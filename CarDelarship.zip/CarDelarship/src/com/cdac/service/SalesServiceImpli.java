package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.SalesDao;
import com.cdac.dto.Sales;
@Service
public class SalesServiceImpli implements SalesService{
@Autowired
	private SalesDao salesdao;
	
	@Override
	public void addRecord(Sales sal) {
		// TODO Auto-generated method stub
	salesdao.addRecord(sal);
	}

	@Override
	public void removeRecord(int salesId) {
		// TODO Auto-generated method stub
		salesdao.removeRecord(salesId);
	}

	@Override
	public List<Sales> selectAll() {
		// TODO Auto-generated method stub
		return salesdao.selectAll();
	}

	@Override
	public void modifyRecord(Sales sales) {
		// TODO Auto-generated method stub
		salesdao.updateRecord(sales);
	}

	@Override
	public Sales findExpenxe(int salesId) {
		
		return salesdao.selectRecord(salesId);
	}

	

}
