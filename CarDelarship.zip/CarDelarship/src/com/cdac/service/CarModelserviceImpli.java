package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.CarModelDao;
import com.cdac.dto.CarModel;
@Service
public class CarModelserviceImpli implements CarModelservice {

	@Autowired
	private CarModelDao carDao;
	@Override
	public void insertcar(CarModel car) {
		
		carDao.addCar(car);
	}
	@Override
	public void removeCar(int chassino) {
		carDao.deleteModel(chassino);
	}
	@Override
	public CarModel findCar(int chassino) {
		// TODO Auto-generated method stub
		return carDao.selectModel(chassino);
	}
	
	
	@Override
	public List<CarModel> selectAll(int userId) {
		// TODO Auto-generated method stub
		return carDao.selectAll(userId);
	}
	@Override
	public void modifyCar(CarModel car) {
		// TODO Auto-generated method stub
		carDao.updateModek(car);
	}

}
