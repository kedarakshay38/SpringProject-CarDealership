package com.cdac.service;

import com.cdac.dto.Admin;

public interface AdminService {
	void addUser(Admin admin);
	boolean findUser(Admin admin);
}
