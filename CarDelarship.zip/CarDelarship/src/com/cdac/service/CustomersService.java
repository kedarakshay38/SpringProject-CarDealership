package com.cdac.service;

import java.util.List;

import com.cdac.dto.Customers;


public interface CustomersService {
	void insertcar(Customers cus);
	void removeCus(int customerId);
	Customers findCus(int customerId);
	void modifyCus(Customers  customer);
	List<Customers > selectAll();
}
