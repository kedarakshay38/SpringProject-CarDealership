package com.cdac.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.AdminDao;
import com.cdac.dto.Admin;
@Service
public class AdminServiceimpli implements AdminService {
@Autowired
	private AdminDao adminDao;
	
	@Override
	public void addUser(Admin admin) {
		// TODO Auto-generated method stub
		adminDao.insertUser(admin);
	}

	@Override
	public boolean findUser(Admin admin) {
		// TODO Auto-generated method stub
		return adminDao.checkUser(admin);
	}

}
