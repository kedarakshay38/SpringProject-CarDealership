package com.cdac.service;

import java.util.List;


import com.cdac.dto.Sales;

public interface SalesService {
void addRecord(Sales sal);
	
	void removeRecord(int salesId );
	void modifyRecord(Sales sales);
	List<Sales> selectAll();

	Sales findExpenxe(int salesId);
}
