package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.CustomersDao;
import com.cdac.dto.Customers;
@Service
public class CustomersServiceImpli implements CustomersService{
@Autowired
	private CustomersDao customersDao;
	@Override
	public void insertcar(Customers cus) {
		
		customersDao.addCustomer(cus);
	}
	@Override
	public void removeCus(int customerId) {
		// TODO Auto-generated method stub
		customersDao.deleteExpense(customerId);
		
	}
	@Override
	public Customers findCus(int customerId) {
		// TODO Auto-generated method stub
		return customersDao.selectExpenxe(customerId);
	}
	@Override
	public void modifyCus(Customers customer) {
		// TODO Auto-generated method stub
		customersDao.updateExpense(customer);
		
	}
	@Override
	public List<Customers> selectAll() {
		// TODO Auto-generated method stub
		return customersDao.selectAll();
	}

}
