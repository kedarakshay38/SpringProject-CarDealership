package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="carmodel")
public class CarModel {
	@Id
	@GeneratedValue
	@Column(name ="chassi_no")
	private int chassino;
	
	@Column(name="car_model")
	private String model;
	
	@Column(name="variant")
	private String variant;

	private int userId;
	


	
	
	public CarModel(int chassino, String model, String variant, int userId) {
		super();
		this.chassino = chassino;
		this.model = model;
		this.variant = variant;
		this.userId = userId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getVariant() {
		return variant;
	}

	public void setVariant(String variant) {
		this.variant = variant;
	}

	public CarModel(int chassino) {
		super();
		this.chassino = chassino;
	}

	public CarModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getChassino() {
		return chassino;
	}

	public void setChassino(int chassino) {
		this.chassino = chassino;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}
	
	

}
