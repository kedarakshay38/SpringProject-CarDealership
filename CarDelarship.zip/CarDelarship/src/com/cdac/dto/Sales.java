package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="Sales")
public class Sales {
	
	@Id
	@GeneratedValue
	@Column(name = "sales_id")
	private int salesId;
	
	@Column(name = "sales_date")
	private String date;
	
	@Column(name = "Customer")
	private String customer;
	
	@Column(name = "Car_Model")
	private String carModel;
	
	
	@Column(name = "Price")
	private String Price;
	
	private int userId;
	
	
	public Sales(int salesId, String date, String customer, String carModel, String price, int userId) {
		super();
		this.salesId = salesId;
		this.date = date;
		this.customer = customer;
		this.carModel = carModel;
		Price = price;
		this.userId = userId;
	}

	public String getCarModel() {
		return carModel;
	}

	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}

	public String getPrice() {
		return Price;
	}

	public void setPrice(String price) {
		Price = price;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	

	public Sales(int salesId) {
		super();
		this.salesId = salesId;
	}

	public Sales() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getSalesId() {
		return salesId;
	}

	public void setSalesId(int salesId) {
		this.salesId = salesId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	
}
