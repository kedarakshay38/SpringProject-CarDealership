package com.cdac.dao;

import java.util.List;


import com.cdac.dto.Sales;

public interface SalesDao {

	void addRecord(Sales sal);
	
	void removeRecord(int salesId );
	
	List<Sales> selectAll();
	Sales selectRecord(int salesId);
	void updateRecord(Sales sales);
}
