package com.cdac.dao;

import java.util.List;

import com.cdac.dto.CarModel;


public interface CarModelDao {
 void addCar(CarModel car);
 
 void deleteModel(int chassino);
	CarModel selectModel(int chassino);
	void updateModek(CarModel car);
	List<CarModel> selectAll(int userId);
}
