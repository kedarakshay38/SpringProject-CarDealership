package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.dto.CarModel;


@Repository
public class carModelDaoImpli implements CarModelDao  {

	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public void addCar(CarModel car){
	
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException 
			{
				Transaction tr = session.beginTransaction();
				session.save(car);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

	@Override
	public void deleteModel(int chassino) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.delete(new CarModel(chassino));
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

	@Override
	public CarModel selectModel(int chassino) {
		CarModel car = hibernateTemplate.execute(new HibernateCallback<CarModel>() {

			@Override
			public CarModel doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				CarModel ca = (CarModel)session.get(CarModel.class, chassino);
				tr.commit();
				session.flush();
				session.close();
				return ca;
			}
			
		});
		return car;
	
	}

	
	@Override
	public List<CarModel> selectAll(int userId) {
		List<CarModel> carList = hibernateTemplate.execute(new HibernateCallback<List<CarModel>>() {

			@Override
			public List<CarModel> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from CarModel where userId = ?");
				q.setInteger(0, userId);
				List<CarModel> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return carList;
	}

	@Override
	public void updateModek(CarModel car) {
		// TODO Auto-generated method stub
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				
//				Expense ex = (Expense)session.get(Expense.class, expense.getExpenseId());
//				ex.setItemName(expense.getItemName());
//				ex.setPrice(expense.getPrice());
//				ex.setPurchaseDate(expense.getPurchaseDate()); 
				
				session.update(car);
				
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
	}
	}


