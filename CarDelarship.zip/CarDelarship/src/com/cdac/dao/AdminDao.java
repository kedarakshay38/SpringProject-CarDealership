package com.cdac.dao;

import com.cdac.dto.Admin;

public interface AdminDao {
	void insertUser(Admin admin);
	boolean checkUser(Admin admin);

}
