package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;


import com.cdac.dto.Sales;
@Repository
public class SalesDaoImpli implements  SalesDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public void addRecord(Sales sal){
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException 
			{
				Transaction tr = session.beginTransaction();
				session.save(sal);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
		
	}

	@Override
	public void removeRecord(int salesId) {
		// TODO Auto-generated method stub
		
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.delete(new Sales(salesId));
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

	@Override
	public List<Sales> selectAll() {
		// TODO Auto-generated method stub
		List<Sales> salesList = hibernateTemplate.execute(new HibernateCallback<List<Sales>>() {

			@Override
			public List<Sales> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Sales ");
				List<Sales> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
				}
			
		});
		return salesList;
	}

	@Override
	public void updateRecord(Sales sales) {
		// TODO Auto-generated method stub
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
			
				session.update(sales);
				
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
	}

	@Override
	public Sales selectRecord(int salesId) {
		Sales sales = hibernateTemplate.execute(new HibernateCallback<Sales>() {

			@Override
			public Sales doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Sales ex = (Sales)session.get(Sales.class, salesId);
				tr.commit();
				session.flush();
				session.close();
				return ex;
			}
			
		});
		return sales;
	}

	
		
}
