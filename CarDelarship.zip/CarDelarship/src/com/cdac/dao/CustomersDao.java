package com.cdac.dao;



import java.util.List;

import com.cdac.dto.Customers;

public interface CustomersDao {
	
	 void addCustomer(Customers cus);

	void deleteExpense(int customerId);

	Customers selectExpenxe(int customerId);

	List<Customers> selectAll();

	void updateExpense(Customers customer);
	 
	 
}
