package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.dto.Customers;



@Repository
public class CustomerDaoImpli implements CustomersDao{

	@Autowired
	private HibernateTemplate hibernateTemplate;


	@Override
	public void addCustomer(Customers cus) {
		// TODO Auto-generated method stub

		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException 
			{
				Transaction tr = session.beginTransaction();
				session.save(cus);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}


	


	@Override
	public Customers selectExpenxe(int customerId) {
		Customers customers = hibernateTemplate.execute(new HibernateCallback<Customers>() {

			@Override
			public Customers doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Customers ex = (Customers)session.get(Customers.class, customerId);
				tr.commit();
				session.flush();
				session.close();
				return ex;
			}
			
		});
		return customers;
	}


	@Override
	public List<Customers> selectAll() {
		List<Customers> expList = hibernateTemplate.execute(new HibernateCallback<List<Customers>>() {

			@Override
			public List<Customers> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Customers ");
				
				List<Customers> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return expList;
	}


	@Override
	public void deleteExpense(int customerId) {
		// TODO Auto-generated method stub
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.delete(new Customers(customerId));
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
	}





	@Override
	public void updateExpense(Customers customer) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
			
				session.update(customer);
				
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

	
	

}
