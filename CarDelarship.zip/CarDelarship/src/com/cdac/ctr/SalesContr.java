package com.cdac.ctr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cdac.dto.Admin;
import com.cdac.dto.CarModel;

import com.cdac.dto.Sales;

import com.cdac.service.SalesService;

@Controller
public class SalesContr {

	@Autowired
	private SalesService salesServ;
	

	@RequestMapping(value = "/prep_sales.htm",method = RequestMethod.GET)
	public String InsertCar(ModelMap map) {
		map.put("sales", new Sales());
		return "Sales_insertRecordform";
	}

	@RequestMapping(value = "/SalesRecorded.htm",method = RequestMethod.POST)
	public String carInserted(Sales sal,HttpSession session) {
		int userId = ((Admin)session.getAttribute("admin")).getUserId();
		sal.setUserId(userId); 
		salesServ.addRecord(sal);
		return "home";
	}
	
	
	@RequestMapping(value = "/Service_list.htm",method = RequestMethod.GET)
	public String allCars(ModelMap map,HttpSession session) {
		
		List<Sales> li = salesServ.selectAll();
		map.put("salesList", li);
		return "Sales_Record";
	}

	@RequestMapping(value = "/record_delete.htm",method = RequestMethod.GET)
	public String expenseDelete(@RequestParam int salesId ,ModelMap map,HttpSession session) {
		
		salesServ.removeRecord(salesId); 
		
		
		List<Sales> li = salesServ.selectAll();
		map.put("salesList", li);
		return "Sales_Record";
	}
	
	
	@RequestMapping(value = "/sales_update_form.htm",method = RequestMethod.GET)
	public String expenseUpdateForm(@RequestParam int salesId,ModelMap map) {
		
		Sales sales = salesServ.findExpenxe(salesId);
		System.out.println(sales);
		map.put("sales", sales);
		
		return "Sales_update_form";
	}
	
	@RequestMapping(value = "/sales_updated.htm",method = RequestMethod.POST)
	public String expenseUpdate(Sales sales,ModelMap map,HttpSession session) {
		
		int userId =1;
		sales.setUserId(userId);
		salesServ.modifyRecord(sales);
			
		List<Sales> li = salesServ.selectAll();
		map.put("salesList", li);
		return "Sales_Record";
	}
}
