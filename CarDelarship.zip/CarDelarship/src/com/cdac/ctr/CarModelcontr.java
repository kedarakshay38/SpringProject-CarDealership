package com.cdac.ctr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cdac.dto.Admin;
import com.cdac.dto.CarModel;

import com.cdac.service.CarModelservice;

@Controller
public class CarModelcontr {
@Autowired
	private CarModelservice carservice;

	@RequestMapping(value = "/newCar.htm",method = RequestMethod.GET)
	public String InsertCar(ModelMap map) {
		map.put("car", new CarModel());
		return "Car_insertform";
	}
	
	@RequestMapping(value = "/Car_inserted.htm",method = RequestMethod.POST)
	public String carInserted(CarModel car,HttpSession session) {
		int userId = ((Admin)session.getAttribute("admin")).getUserId();
		car.setUserId(userId); 
		carservice.insertcar(car);
		return "home";
	}
	
	@RequestMapping(value = "/Car_list.htm",method = RequestMethod.GET)
	public String allCars(ModelMap map,HttpSession session) {
		int userId = ((Admin)session.getAttribute("admin")).getUserId();
		List<CarModel> li = carservice.selectAll(userId);
		map.put("carList", li);
		return "Car_list";
	}
	
	@RequestMapping(value = "/car_delete.htm",method = RequestMethod.GET)
	public String expenseDelete(@RequestParam int chassino,ModelMap map,HttpSession session) {
		
		carservice.removeCar(chassino); 
		
		int userId = ((Admin)session.getAttribute("admin")).getUserId();
		List<CarModel> li = carservice.selectAll(userId);
		map.put("carList", li);
		return "Car_list";
	}
	
	
	@RequestMapping(value = "/car_update_form.htm",method = RequestMethod.GET)
	public String expenseUpdateForm(@RequestParam int chassino,ModelMap map) {
		
		CarModel car= carservice.findCar(chassino);
		map.put("car", car);
		
		return "car_update_form";
	}
	
	@RequestMapping(value = "/car_updated.htm",method = RequestMethod.POST)
	public String expenseUpdate(CarModel car,ModelMap map,HttpSession session) {
		
		int userId = 1;
		car.setUserId(userId);
		carservice.modifyCar(car);
			
		
		List<CarModel> li = carservice.selectAll(userId);
		map.put("carList", li);
		return "Car_list";
	}
	

	
}
