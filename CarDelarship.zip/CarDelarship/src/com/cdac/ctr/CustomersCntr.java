package com.cdac.ctr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cdac.dto.Admin;

import com.cdac.dto.Customers;

import com.cdac.service.CustomersService;


@Controller
public class CustomersCntr {
@Autowired
	private CustomersService customersService;


@RequestMapping(value = "/prep_customers.htm",method = RequestMethod.GET)
public String InsertCus(ModelMap map) {
	map.put("cus", new Customers());
	return "customer_insert";
}

@RequestMapping(value = "/Customer_inserted.htm",method = RequestMethod.POST)
public String carInserted(Customers cus,HttpSession session) {

	int userId = ((Admin)session.getAttribute("admin")).getUserId();
	cus.setUserId(userId); 
	customersService.insertcar(cus);
	return "home";
}

@RequestMapping(value = "/customers_list.htm",method = RequestMethod.GET)
public String allExpenses(ModelMap map,HttpSession session) {
	
	List<Customers> li = customersService.selectAll();
	map.put("cusList", li);
	return "cus_list";
}

@RequestMapping(value = "/expense_delete.htm",method = RequestMethod.GET)
public String expenseDelete(@RequestParam int customerId,ModelMap map,HttpSession session) {
	
	customersService.removeCus(customerId); 
	
	
	List<Customers> li = customersService.selectAll();
	map.put("cusList", li);
	return "cus_list";
}

}
